<?php
$current_page = 'contact';
$page_title = 'İletişim | Bilay Demir Doğrama';

include 'includes/header.php';

$success = false;
$error = '';

// Form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $message = sanitize($_POST['message'] ?? '');
    
    if (empty($name) || empty($email) || empty($message)) {
        $error = 'Lütfen zorunlu alanları doldurun.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Geçerli bir e-posta adresi girin.';
    } else {
        try {
            insert('contact_messages', [
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'message' => $message
            ]);
            
            // Send email notification
            $emailBody = "
                <h2>Yeni İletişim Mesajı</h2>
                <p><strong>Ad:</strong> $name</p>
                <p><strong>E-posta:</strong> $email</p>
                <p><strong>Telefon:</strong> " . ($phone ?: 'Belirtilmedi') . "</p>
                <p><strong>Mesaj:</strong> $message</p>
            ";
            sendEmail(ADMIN_EMAIL, 'Yeni İletişim Mesajı - Bilay Demir Doğrama', $emailBody);
            
            $success = true;
        } catch (Exception $e) {
            $error = 'Bir hata oluştu. Lütfen tekrar deneyin.';
        }
    }
}
?>

<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <div class="section-label">İLETİŞİM</div>
        <h1>Bizimle İletişime Geçin</h1>
        <p class="text-secondary" style="margin-top: 24px; max-width: 500px; font-size: 18px;">
            Sorularınız için bize ulaşın, en kısa sürede dönelim.
        </p>
    </div>
</section>

<!-- Contact Content -->
<section class="section" style="background: var(--bg-primary);">
    <div class="container">
        <div class="contact-grid">
            <!-- Contact Info -->
            <div>
                <h2 style="margin-bottom: 32px;">İletişim Bilgileri</h2>
                
                <a href="tel:<?= getSetting('phone') ?>" class="contact-item">
                    <i class="fas fa-phone"></i>
                    <div>
                        <div class="contact-item-label">TELEFON</div>
                        <div class="contact-item-value"><?= getSetting('phone', '+90 212 555 12 34') ?></div>
                    </div>
                </a>
                
                <a href="mailto:<?= getSetting('email') ?>" class="contact-item" style="margin-top: 16px;">
                    <i class="fas fa-envelope"></i>
                    <div>
                        <div class="contact-item-label">E-POSTA</div>
                        <div class="contact-item-value"><?= getSetting('email', 'info@bilaydemir.com') ?></div>
                    </div>
                </a>
                
                <div class="contact-item" style="margin-top: 16px;">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>
                        <div class="contact-item-label">ADRES</div>
                        <div class="contact-item-value"><?= getSetting('address', 'Kağıthane, İstanbul') ?></div>
                    </div>
                </div>
                
                <div class="contact-item" style="margin-top: 16px;">
                    <i class="fas fa-clock"></i>
                    <div>
                        <div class="contact-item-label">ÇALIŞMA SAATLERİ</div>
                        <div class="contact-item-value"><?= getSetting('working_hours', 'Pzt - Cmt: 08:00 - 18:00') ?></div>
                    </div>
                </div>
            </div>
            
            <!-- Contact Form -->
            <div>
                <h2 style="margin-bottom: 32px;">Mesaj Gönderin</h2>
                
                <?php if ($success): ?>
                <div class="alert alert-success">
                    <strong>Mesajınız Alındı!</strong> En kısa sürede size döneceğiz.
                </div>
                <?php else: ?>
                
                <?php if ($error): ?>
                <div class="alert alert-error"><?= $error ?></div>
                <?php endif; ?>
                
                <form method="POST" data-validate>
                    <div class="form-group">
                        <label>AD SOYAD *</label>
                        <input type="text" name="name" required placeholder="Adınızı girin">
                    </div>
                    
                    <div class="form-group">
                        <label>E-POSTA *</label>
                        <input type="email" name="email" required placeholder="E-posta adresinizi girin">
                    </div>
                    
                    <div class="form-group">
                        <label>TELEFON</label>
                        <input type="tel" name="phone" placeholder="Telefon numaranızı girin">
                    </div>
                    
                    <div class="form-group">
                        <label>MESAJ *</label>
                        <textarea name="message" rows="5" required placeholder="Mesajınızı yazın"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-paper-plane"></i> Mesaj Gönder
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Map -->
        <div class="map-container">
            <iframe 
                src="<?= getSetting('google_maps_embed', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d48173.29!2d28.97!3d41.08!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14cab7650656bd63%3A0x8ca058b28c20b6c3!2zS8OixJ%2FEsXRoYW5lLCDEsHN0YW5idWw!5e0!3m2!1str!2str!4v1') ?>"
                allowfullscreen=""
                loading="lazy"
                title="Bilay Demir Doğrama Konum">
            </iframe>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
