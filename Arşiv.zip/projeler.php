<?php
$current_page = 'projects';
$page_title = 'Projelerimiz | Bilay Demir Doğrama';
include 'includes/header.php';

$projects = fetchAll("SELECT * FROM projects ORDER BY created_at DESC");
$categories = array_unique(array_column($projects, 'category'));
?>

<section class="page-header">
    <div class="container">
        <div class="section-label">PORTFÖY</div>
        <h1>Tamamlanan Projelerimiz</h1>
        <p class="text-secondary" style="margin-top: 24px; max-width: 500px; font-size: 18px;">
            Yıllar içinde tamamladığımız projelerden örnekler.
        </p>
    </div>
</section>

<section class="section" style="background: var(--bg-primary);">
    <div class="container">
        <?php if (!empty($categories)): ?>
        <div class="filters">
            <button class="filter-btn active" data-category="all" onclick="filterProjects('all')">Tümü</button>
            <?php foreach ($categories as $cat): ?>
            <button class="filter-btn" data-category="<?= htmlspecialchars($cat) ?>" onclick="filterProjects('<?= htmlspecialchars($cat) ?>')">
                <?= htmlspecialchars($cat) ?>
            </button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <?php if (count($projects) > 0): ?>
        <div class="projects-grid">
            <?php foreach ($projects as $project): 
                $images = json_decode($project['images'], true) ?: [];
                $firstImage = $images[0] ?? '/assets/images/placeholder.jpg';
            ?>
            <div class="project-card" data-category="<?= htmlspecialchars($project['category']) ?>">
                <img src="<?= htmlspecialchars($firstImage) ?>" alt="<?= htmlspecialchars($project['title']) ?>">
                <div class="project-overlay">
                    <span class="project-category"><?= htmlspecialchars($project['category']) ?></span>
                    <h4 class="project-title"><?= htmlspecialchars($project['title']) ?></h4>
                    <p style="font-size: 14px; color: var(--text-secondary); margin-top: 8px;">
                        <?= htmlspecialchars(truncate($project['description'], 100)) ?>
                    </p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="empty-state">
            <p>Henüz proje eklenmemiş.</p>
            <p>Yakında projelerimizi burada görebilirsiniz.</p>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
