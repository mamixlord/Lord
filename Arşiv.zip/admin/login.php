<?php
require_once __DIR__ . '/../includes/functions.php';

startSession();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $error = 'Lütfen e-posta ve şifre girin.';
    } else {
        $user = fetchOne("SELECT * FROM users WHERE email = ?", [$email]);
        
        if ($user && verifyPassword($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_role'] = $user['role'];
            
            header('Location: /admin/');
            exit;
        } else {
            $error = 'Geçersiz e-posta veya şifre.';
        }
    }
}

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: /admin/');
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Girişi | Bilay Demir Doğrama</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/style.css">
    <style>
        .login-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        .login-box {
            width: 100%;
            max-width: 400px;
            padding: 48px;
            background: var(--bg-surface);
            border: 1px solid var(--border-color);
        }
        .login-logo {
            text-align: center;
            margin-bottom: 40px;
        }
        .login-logo .logo-icon {
            width: 64px;
            height: 64px;
            font-size: 32px;
            margin: 0 auto 24px;
        }
        .login-logo h1 {
            font-size: 24px;
            margin-bottom: 8px;
        }
        .login-logo p {
            color: var(--text-secondary);
            font-size: 14px;
        }
        .input-icon {
            position: relative;
        }
        .input-icon i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-secondary);
        }
        .input-icon input {
            padding-left: 44px;
        }
    </style>
</head>
<body>
    <div class="login-page">
        <div class="login-box">
            <div class="login-logo">
                <div class="logo-icon">B</div>
                <h1>Admin Paneli</h1>
                <p>Yönetim paneline giriş yapın</p>
            </div>
            
            <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label>E-POSTA</label>
                    <div class="input-icon">
                        <i class="fas fa-envelope"></i>
                        <input type="email" name="email" required placeholder="admin@bilaydemir.com">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>ŞİFRE</label>
                    <div class="input-icon">
                        <i class="fas fa-lock"></i>
                        <input type="password" name="password" required placeholder="••••••••">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    Giriş Yap
                </button>
            </form>
        </div>
    </div>
</body>
</html>
