<?php
$admin_title = 'Dashboard';
include 'includes/header.php';

// Get stats
$offersTotal = fetchOne("SELECT COUNT(*) as count FROM offer_requests")['count'];
$offersNew = fetchOne("SELECT COUNT(*) as count FROM offer_requests WHERE status = 'new'")['count'];
$messagesTotal = fetchOne("SELECT COUNT(*) as count FROM contact_messages")['count'];
$messagesUnread = fetchOne("SELECT COUNT(*) as count FROM contact_messages WHERE status = 'unread'")['count'];
$projectsCount = fetchOne("SELECT COUNT(*) as count FROM projects")['count'];
$blogCount = fetchOne("SELECT COUNT(*) as count FROM blog_posts")['count'];

// Recent offers
$recentOffers = fetchAll("SELECT * FROM offer_requests ORDER BY created_at DESC LIMIT 5");
// Recent messages
$recentMessages = fetchAll("SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT 5");
?>

<!-- Stats Grid -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 32px;">
    <div class="stat-card">
        <div class="stat-card-header">
            <div class="stat-card-icon" style="background: rgba(255, 90, 0, 0.2);">
                <i class="fas fa-file-invoice" style="color: #FF5A00;"></i>
            </div>
            <span style="color: var(--text-secondary); font-size: 14px;">Teklif Talepleri</span>
        </div>
        <div class="stat-card-value"><?= $offersTotal ?></div>
        <div class="stat-card-sub" style="color: #FF5A00;"><?= $offersNew ?> yeni</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-card-header">
            <div class="stat-card-icon" style="background: rgba(59, 130, 246, 0.2);">
                <i class="fas fa-envelope" style="color: #3B82F6;"></i>
            </div>
            <span style="color: var(--text-secondary); font-size: 14px;">Mesajlar</span>
        </div>
        <div class="stat-card-value"><?= $messagesTotal ?></div>
        <div class="stat-card-sub" style="color: #3B82F6;"><?= $messagesUnread ?> okunmamış</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-card-header">
            <div class="stat-card-icon" style="background: rgba(16, 185, 129, 0.2);">
                <i class="fas fa-images" style="color: #10B981;"></i>
            </div>
            <span style="color: var(--text-secondary); font-size: 14px;">Projeler</span>
        </div>
        <div class="stat-card-value"><?= $projectsCount ?></div>
    </div>
    
    <div class="stat-card">
        <div class="stat-card-header">
            <div class="stat-card-icon" style="background: rgba(139, 92, 246, 0.2);">
                <i class="fas fa-newspaper" style="color: #8B5CF6;"></i>
            </div>
            <span style="color: var(--text-secondary); font-size: 14px;">Blog Yazıları</span>
        </div>
        <div class="stat-card-value"><?= $blogCount ?></div>
    </div>
</div>

<!-- Recent Data -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 24px;">
    <!-- Recent Offers -->
    <div>
        <h3 style="margin-bottom: 16px;">Son Teklif Talepleri</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Ad</th>
                    <th>Hizmet</th>
                    <th>Tarih</th>
                    <th>Durum</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentOffers as $offer): ?>
                <tr>
                    <td><?= htmlspecialchars($offer['name']) ?></td>
                    <td><?= htmlspecialchars($offer['service']) ?></td>
                    <td><?= formatDate($offer['created_at']) ?></td>
                    <td>
                        <span class="badge <?= $offer['status'] == 'new' ? 'badge-new' : 'badge-secondary' ?>">
                            <?= $offer['status'] == 'new' ? 'Yeni' : ucfirst($offer['status']) ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($recentOffers)): ?>
                <tr><td colspan="4" style="text-align: center; color: var(--text-secondary);">Henüz teklif yok</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <a href="/admin/offers.php" style="display: block; text-align: center; padding: 16px; color: var(--color-primary); font-size: 14px;">
            Tümünü Gör →
        </a>
    </div>
    
    <!-- Recent Messages -->
    <div>
        <h3 style="margin-bottom: 16px;">Son Mesajlar</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Ad</th>
                    <th>E-posta</th>
                    <th>Tarih</th>
                    <th>Durum</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentMessages as $msg): ?>
                <tr>
                    <td><?= htmlspecialchars($msg['name']) ?></td>
                    <td><?= htmlspecialchars($msg['email']) ?></td>
                    <td><?= formatDate($msg['created_at']) ?></td>
                    <td>
                        <span class="badge <?= $msg['status'] == 'unread' ? 'badge-new' : 'badge-secondary' ?>">
                            <?= $msg['status'] == 'unread' ? 'Okunmamış' : 'Okundu' ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($recentMessages)): ?>
                <tr><td colspan="4" style="text-align: center; color: var(--text-secondary);">Henüz mesaj yok</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <a href="/admin/messages.php" style="display: block; text-align: center; padding: 16px; color: var(--color-primary); font-size: 14px;">
            Tümünü Gör →
        </a>
    </div>
</div>

<!-- Quick Actions -->
<div style="margin-top: 32px; padding: 24px; background: var(--bg-surface); border: 1px solid var(--border-color);">
    <h3 style="margin-bottom: 20px;">Hızlı İşlemler</h3>
    <div style="display: flex; gap: 12px; flex-wrap: wrap;">
        <a href="/admin/projects.php?action=new" class="btn btn-outline">
            <i class="fas fa-plus"></i> Yeni Proje
        </a>
        <a href="/admin/blog.php?action=new" class="btn btn-outline">
            <i class="fas fa-plus"></i> Blog Yazısı
        </a>
        <a href="/admin/offers.php" class="btn btn-outline">
            <i class="fas fa-eye"></i> Talepleri Gör
        </a>
        <a href="/admin/messages.php" class="btn btn-outline">
            <i class="fas fa-envelope"></i> Mesajları Gör
        </a>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
