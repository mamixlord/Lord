            </div>
        </main>
    </div>
    
    <script>
        // Sidebar toggle for mobile
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        
        if (window.innerWidth <= 1024) {
            sidebarToggle.style.display = 'block';
        }
        
        sidebarToggle?.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
        
        // Confirm delete
        function confirmDelete(message) {
            return confirm(message || 'Bu öğeyi silmek istediğinize emin misiniz?');
        }
    </script>
</body>
</html>
