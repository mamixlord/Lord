<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();

$current_admin_page = basename($_SERVER['PHP_SELF'], '.php');
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $admin_title ?? 'Admin Panel' ?> | Bilay Demir Doğrama</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/style.css">
    <style>
        .admin-layout { display: flex; min-height: 100vh; }
        .admin-sidebar {
            width: 260px;
            background: var(--bg-surface);
            border-right: 1px solid var(--border-color);
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            display: flex;
            flex-direction: column;
            z-index: 100;
        }
        .admin-sidebar-header {
            padding: 24px;
            border-bottom: 1px solid var(--border-color);
        }
        .admin-nav {
            flex: 1;
            padding: 16px 0;
            overflow-y: auto;
        }
        .admin-nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 24px;
            color: var(--text-secondary);
            font-size: 14px;
            border-left: 3px solid transparent;
            transition: all 0.2s ease;
        }
        .admin-nav-link:hover, .admin-nav-link.active {
            color: var(--color-primary);
            background: rgba(255, 90, 0, 0.1);
            border-left-color: var(--color-primary);
        }
        .admin-sidebar-footer {
            padding: 16px 24px;
            border-top: 1px solid var(--border-color);
        }
        .admin-main {
            flex: 1;
            margin-left: 260px;
        }
        .admin-header {
            height: 64px;
            background: var(--bg-surface);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .admin-header h1 { font-size: 18px; }
        .admin-content { padding: 24px; }
        .stat-card {
            background: var(--bg-surface);
            border: 1px solid var(--border-color);
            padding: 24px;
        }
        .stat-card-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
        }
        .stat-card-icon {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
        }
        .stat-card-value { font-size: 32px; font-weight: 700; }
        .stat-card-sub { font-size: 13px; margin-top: 4px; }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            background: var(--bg-surface);
            border: 1px solid var(--border-color);
        }
        .data-table th, .data-table td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        .data-table th {
            font-size: 12px;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .data-table tr:last-child td { border-bottom: none; }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-new { background: rgba(255, 90, 0, 0.2); color: #FF5A00; }
        .badge-success { background: rgba(16, 185, 129, 0.2); color: #10B981; }
        .badge-secondary { background: rgba(161, 161, 170, 0.2); color: #A1A1AA; }
        .action-btn {
            background: transparent;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            padding: 8px;
            transition: color 0.2s;
        }
        .action-btn:hover { color: var(--color-primary); }
        .action-btn.delete:hover { color: #EF4444; }
        @media (max-width: 1024px) {
            .admin-sidebar { transform: translateX(-100%); }
            .admin-sidebar.open { transform: translateX(0); }
            .admin-main { margin-left: 0; }
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <!-- Sidebar -->
        <aside class="admin-sidebar" id="sidebar">
            <div class="admin-sidebar-header">
                <a href="/" class="logo">
                    <div class="logo-icon" style="width: 40px; height: 40px; font-size: 20px;">B</div>
                    <div class="logo-text">
                        <span class="logo-name" style="font-size: 14px;">BILAY</span>
                        <span class="logo-sub" style="font-size: 10px;">ADMIN PANEL</span>
                    </div>
                </a>
            </div>
            
            <nav class="admin-nav">
                <a href="/admin/" class="admin-nav-link <?= $current_admin_page == 'index' ? 'active' : '' ?>">
                    <i class="fas fa-chart-pie"></i> Dashboard
                </a>
                <a href="/admin/services.php" class="admin-nav-link <?= $current_admin_page == 'services' ? 'active' : '' ?>">
                    <i class="fas fa-cogs"></i> Hizmetler
                </a>
                <a href="/admin/projects.php" class="admin-nav-link <?= $current_admin_page == 'projects' ? 'active' : '' ?>">
                    <i class="fas fa-images"></i> Projeler
                </a>
                <a href="/admin/blog.php" class="admin-nav-link <?= $current_admin_page == 'blog' ? 'active' : '' ?>">
                    <i class="fas fa-newspaper"></i> Blog
                </a>
                <a href="/admin/offers.php" class="admin-nav-link <?= $current_admin_page == 'offers' ? 'active' : '' ?>">
                    <i class="fas fa-file-invoice"></i> Teklif Talepleri
                </a>
                <a href="/admin/messages.php" class="admin-nav-link <?= $current_admin_page == 'messages' ? 'active' : '' ?>">
                    <i class="fas fa-envelope"></i> Mesajlar
                </a>
                <a href="/admin/testimonials.php" class="admin-nav-link <?= $current_admin_page == 'testimonials' ? 'active' : '' ?>">
                    <i class="fas fa-star"></i> Referanslar
                </a>
                <a href="/admin/seo.php" class="admin-nav-link <?= $current_admin_page == 'seo' ? 'active' : '' ?>">
                    <i class="fas fa-search"></i> SEO Ayarları
                </a>
                <a href="/admin/settings.php" class="admin-nav-link <?= $current_admin_page == 'settings' ? 'active' : '' ?>">
                    <i class="fas fa-sliders-h"></i> Site Ayarları
                </a>
            </nav>
            
            <div class="admin-sidebar-footer">
                <div style="font-size: 13px; color: var(--text-secondary); margin-bottom: 8px;">
                    <?= htmlspecialchars($user['email']) ?>
                </div>
                <a href="/admin/logout.php" style="color: var(--color-primary); font-size: 14px;">
                    <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="admin-main">
            <header class="admin-header">
                <div style="display: flex; align-items: center; gap: 16px;">
                    <button class="action-btn" id="sidebarToggle" style="display: none;">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1><?= $admin_title ?? 'Dashboard' ?></h1>
                </div>
                <a href="/" target="_blank" style="color: var(--text-secondary); font-size: 14px;">
                    Siteyi Gör <i class="fas fa-external-link-alt"></i>
                </a>
            </header>
            
            <div class="admin-content">
