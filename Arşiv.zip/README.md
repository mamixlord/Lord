# Bilay Demir Doğrama - PHP + MySQL Versiyonu

## Gereksinimler

- PHP 8.0+
- MySQL 8.0+
- Apache veya Nginx web sunucusu
- Composer (opsiyonel)

## Kurulum Adımları

### 1. Dosyaları Yükleyin
Tüm dosyaları sunucunuza yükleyin (örn: `/var/www/html/bilaydemir/`)

### 2. Veritabanını Oluşturun
```bash
mysql -u root -p < database.sql
```

### 3. Yapılandırma
`config.php` dosyasını düzenleyin:

```php
// Veritabanı Ayarları
define('DB_HOST', 'localhost');
define('DB_NAME', 'bilay_demir_dograma');
define('DB_USER', 'veritabani_kullanici');
define('DB_PASS', 'veritabani_sifre');

// Site URL
define('SITE_URL', 'https://siteniz.com');

// E-posta Ayarları (Gmail)
define('SMTP_USER', 'sizin@gmail.com');
define('SMTP_PASS', 'uygulama_sifresi');
```

### 4. Klasör İzinleri
```bash
chmod 755 uploads/
chown www-data:www-data uploads/
```

### 5. Apache Yapılandırması (mod_rewrite)
`.htaccess` dosyası oluşturun:

```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^([^/]+)/?$ $1.php [L,QSA]
```

### 6. Nginx Yapılandırması
```nginx
server {
    listen 80;
    server_name siteniz.com;
    root /var/www/html/bilaydemir;
    index index.php;

    location / {
        try_files $uri $uri/ @rewrite;
    }

    location @rewrite {
        rewrite ^/([^/]+)/?$ /$1.php last;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.0-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location /uploads {
        alias /var/www/html/bilaydemir/uploads;
    }
}
```

## Dosya Yapısı

```
├── admin/                  # Admin paneli
│   ├── index.php          # Dashboard
│   ├── login.php          # Giriş sayfası
│   ├── logout.php         # Çıkış
│   ├── services.php       # Hizmet yönetimi
│   ├── projects.php       # Proje yönetimi
│   ├── blog.php           # Blog yönetimi
│   ├── offers.php         # Teklif talepleri
│   ├── messages.php       # İletişim mesajları
│   ├── testimonials.php   # Referans yönetimi
│   ├── seo.php           # SEO ayarları
│   ├── settings.php       # Site ayarları
│   └── includes/
│       ├── header.php
│       └── footer.php
├── assets/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   └── images/
├── includes/
│   ├── functions.php      # Yardımcı fonksiyonlar
│   ├── header.php         # Site header
│   └── footer.php         # Site footer
├── uploads/               # Yüklenen dosyalar
├── config.php             # Yapılandırma
├── database.sql           # Veritabanı şeması
├── index.php              # Ana sayfa
├── hizmetler.php          # Hizmetler
├── projeler.php           # Projeler
├── hakkimizda.php         # Hakkımızda
├── blog.php               # Blog
├── iletisim.php           # İletişim
├── teklif.php             # Teklif formu
└── README.md
```

## Admin Panel Giriş Bilgileri

**İlk kurulumda:**
- E-posta: `admin@bilaydemir.com`
- Şifre: `password`

⚠️ **ÖNEMLİ:** İlk girişten sonra şifreyi mutlaka değiştirin!

### Şifre Değiştirme (MySQL)
```sql
UPDATE users SET password_hash = '$2y$10$YeniSifreHashi' WHERE email = 'admin@bilaydemir.com';
```

PHP ile hash oluşturmak için:
```php
echo password_hash('YeniSifreniz', PASSWORD_BCRYPT);
```

## Özellikler

### Frontend
- ✅ Modern, responsive tasarım
- ✅ Ana sayfa (Hero, Hizmetler, Projeler, Referanslar)
- ✅ Hizmetler sayfası
- ✅ Proje galerisi (filtreleme)
- ✅ Hakkımızda sayfası
- ✅ Blog sistemi
- ✅ İletişim formu
- ✅ Teklif formu (görsel yükleme)
- ✅ WhatsApp butonu
- ✅ Google Maps entegrasyonu

### Admin Panel
- ✅ Güvenli giriş (şifre hash'leme)
- ✅ Dashboard (istatistikler)
- ✅ Hizmet yönetimi (CRUD)
- ✅ Proje yönetimi (CRUD, görsel yükleme)
- ✅ Blog yönetimi (CRUD, SEO)
- ✅ Referans yönetimi
- ✅ Teklif taleplerini görüntüleme
- ✅ İletişim mesajlarını görüntüleme
- ✅ SEO ayarları
- ✅ Site ayarları

## Güvenlik Önerileri

1. `config.php` dosyasını public erişimden koruyun
2. Production'da hata gösterimini kapatın
3. Güçlü admin şifresi kullanın
4. SSL sertifikası (HTTPS) kullanın
5. Düzenli yedekleme yapın

## Destek

Sorularınız için: info@bilaydemir.com
