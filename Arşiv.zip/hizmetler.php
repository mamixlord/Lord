<?php
$current_page = 'services';
$page_title = 'Hizmetlerimiz | Bilay Demir Doğrama';
include 'includes/header.php';

$services = fetchAll("SELECT * FROM services ORDER BY display_order ASC");
$icons = [
    'door' => 'fa-door-closed', 'fence' => 'fa-border-all', 'scissors' => 'fa-cut',
    'cog' => 'fa-cog', 'sun' => 'fa-sun', 'wrench' => 'fa-wrench'
];
$images = [
    'Demir Kapı' => 'https://images.unsplash.com/photo-1696521938054-399082dd4f8c?w=600',
    'Bahçe Çitleri' => 'https://images.unsplash.com/photo-1598635232306-8953c6a2fbc8?w=600',
    'CNC Kesim' => 'https://images.unsplash.com/photo-1738162837619-5d0b158abcec?w=600',
    'Özel Metal Üretim' => 'https://images.unsplash.com/photo-1720036237334-9263cd28c3d4?w=600',
    'Tente Sistemleri' => 'https://images.unsplash.com/photo-1565618408044-681f42bdd0be?w=600',
    'Kaynak/Tamir' => 'https://images.unsplash.com/photo-1565618408044-681f42bdd0be?w=600'
];
?>

<section class="page-header">
    <div class="container">
        <div class="section-label">HİZMETLERİMİZ</div>
        <h1>Profesyonel Metal İşçilik Hizmetleri</h1>
        <p class="text-secondary" style="margin-top: 24px; max-width: 500px; font-size: 18px;">
            20 yıllık tecrübemizle her türlü metal işinde yanınızdayız.
        </p>
    </div>
</section>

<section class="section" style="background: var(--bg-primary);">
    <div class="container">
        <?php foreach ($services as $i => $service): 
            $iconClass = $icons[$service['icon']] ?? 'fa-wrench';
            $image = $images[$service['title']] ?? 'https://images.unsplash.com/photo-1720036237334-9263cd28c3d4?w=600';
        ?>
        <div class="contact-grid" style="padding: 48px; background: var(--bg-surface); border: 1px solid var(--border-color); margin-bottom: 48px; <?= $i % 2 == 1 ? 'direction: rtl;' : '' ?>">
            <div style="direction: ltr;">
                <div class="service-icon">
                    <i class="fas <?= $iconClass ?>"></i>
                </div>
                <h2 style="margin-bottom: 16px;"><?= htmlspecialchars($service['title']) ?></h2>
                <p class="text-secondary" style="line-height: 1.8; margin-bottom: 24px;">
                    <?= htmlspecialchars($service['description']) ?>
                </p>
                <ul class="check-list">
                    <li><i class="fas fa-check"></i> Kaliteli malzeme</li>
                    <li><i class="fas fa-check"></i> Profesyonel montaj</li>
                    <li><i class="fas fa-check"></i> Garanti belgesi</li>
                </ul>
            </div>
            <div style="direction: ltr; aspect-ratio: 4/3; overflow: hidden;">
                <img src="<?= $image ?>" alt="<?= htmlspecialchars($service['title']) ?>" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
