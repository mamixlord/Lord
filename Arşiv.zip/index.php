<?php
$current_page = 'home';
$page_title = 'Bilay Demir Doğrama | Kağıthane İstanbul - Demir Kapı, Bahçe Çiti, CNC Kesim';
$meta_description = 'Bilay Demir Doğrama - Kağıthane, İstanbul\'da 20 yıllık tecrübeyle demir kapı, bahçe çiti, CNC kesim ve özel metal üretim hizmetleri.';

include 'includes/header.php';

// Get data
$services = fetchAll("SELECT * FROM services ORDER BY display_order ASC LIMIT 6");
$projects = fetchAll("SELECT * FROM projects WHERE featured = 1 ORDER BY created_at DESC LIMIT 6");
$testimonials = fetchAll("SELECT * FROM testimonials ORDER BY created_at DESC LIMIT 3");
?>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-sparks"></div>
    <div class="container">
        <div class="hero-content">
            <span class="hero-badge">KAĞITHANE, İSTANBUL</span>
            <h1>METAL İŞLERİ <span class="text-primary">USTASI</span></h1>
            <p>20 yıllık tecrübemizle demir kapı, bahçe çiti, CNC kesim ve özel metal üretim hizmetleri sunuyoruz. Kalite ve güven bizimle.</p>
            
            <div class="hero-buttons">
                <a href="/teklif.php" class="btn btn-primary">
                    <i class="fas fa-phone"></i> Ücretsiz Teklif Al
                </a>
                <a href="/projeler.php" class="btn btn-outline">
                    Projelerimiz <i class="fas fa-arrow-right"></i>
                </a>
            </div>
            
            <div class="hero-stats">
                <div class="stat-item">
                    <div class="stat-value">20+</div>
                    <div class="stat-label">Yıllık Tecrübe</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">500+</div>
                    <div class="stat-label">Tamamlanan Proje</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">%100</div>
                    <div class="stat-label">Müşteri Memnuniyeti</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Services Section -->
<section class="section" style="background: var(--bg-primary);">
    <div class="container">
        <div class="section-header">
            <div class="section-label">HİZMETLERİMİZ</div>
            <h2>Profesyonel Metal İşleri</h2>
        </div>
        
        <div class="services-grid">
            <?php 
            $icons = [
                'door' => 'fa-door-closed',
                'fence' => 'fa-border-all',
                'scissors' => 'fa-cut',
                'cog' => 'fa-cog',
                'sun' => 'fa-sun',
                'wrench' => 'fa-wrench'
            ];
            foreach ($services as $service): 
                $iconClass = $icons[$service['icon']] ?? 'fa-wrench';
            ?>
            <div class="card service-card">
                <div class="service-icon">
                    <i class="fas <?= $iconClass ?>"></i>
                </div>
                <h3><?= htmlspecialchars($service['title']) ?></h3>
                <p><?= htmlspecialchars($service['description']) ?></p>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div style="text-align: center; margin-top: 48px;">
            <a href="/hizmetler.php" class="btn btn-outline">
                Tüm Hizmetler <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
</section>

<!-- Projects Section -->
<section class="section" style="background: var(--bg-surface);">
    <div class="container">
        <div class="section-header">
            <div class="section-label">PORTFÖY</div>
            <h2>Son Projelerimiz</h2>
        </div>
        
        <?php if (count($projects) > 0): ?>
        <div class="projects-grid">
            <?php foreach ($projects as $project): 
                $images = json_decode($project['images'], true) ?: [];
                $firstImage = $images[0] ?? '/assets/images/placeholder.jpg';
            ?>
            <div class="project-card">
                <img src="<?= htmlspecialchars($firstImage) ?>" alt="<?= htmlspecialchars($project['title']) ?>">
                <div class="project-overlay">
                    <span class="project-category"><?= htmlspecialchars($project['category']) ?></span>
                    <h4 class="project-title"><?= htmlspecialchars($project['title']) ?></h4>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="empty-state">
            <p>Projeler yakında eklenecek</p>
        </div>
        <?php endif; ?>
        
        <div style="text-align: center; margin-top: 48px;">
            <a href="/projeler.php" class="btn btn-outline">
                Tüm Projeler <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
</section>

<!-- Why Us Section -->
<section class="section" style="background: var(--bg-primary);">
    <div class="container">
        <div class="contact-grid" style="align-items: center;">
            <div>
                <div class="section-label">NEDEN BİZ?</div>
                <h2 style="margin-top: 16px; margin-bottom: 32px;">Kalite ve Güvenin Adresi</h2>
                
                <ul class="check-list">
                    <li><i class="fas fa-check-circle"></i> 20 yıllık sektör tecrübesi</li>
                    <li><i class="fas fa-check-circle"></i> Yerinde ücretsiz keşif</li>
                    <li><i class="fas fa-check-circle"></i> Garanti belgeli ürünler</li>
                    <li><i class="fas fa-check-circle"></i> Profesyonel montaj ekibi</li>
                    <li><i class="fas fa-check-circle"></i> Rekabetçi fiyatlar</li>
                    <li><i class="fas fa-check-circle"></i> 7/24 müşteri desteği</li>
                </ul>
                
                <a href="/teklif.php" class="btn btn-primary" style="margin-top: 40px;">
                    <i class="fas fa-phone"></i> Hemen Arayın
                </a>
            </div>
            
            <div class="image-box">
                <img src="https://images.unsplash.com/photo-1720036237334-9263cd28c3d4?w=800" alt="Metal atölyemiz">
                <div class="image-badge">
                    <div class="badge-value">20+</div>
                    <div class="badge-label">YIL TECRÜBE</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="section" style="background: var(--bg-surface);">
    <div class="container">
        <div class="section-header">
            <div class="section-label">REFERANSLAR</div>
            <h2>Müşterilerimiz Ne Diyor?</h2>
        </div>
        
        <div class="testimonials-grid">
            <?php foreach ($testimonials as $testimonial): ?>
            <div class="card testimonial-card">
                <div class="testimonial-stars">
                    <?php for ($i = 0; $i < $testimonial['rating']; $i++): ?>
                    <i class="fas fa-star"></i>
                    <?php endfor; ?>
                </div>
                <p class="testimonial-text">"<?= htmlspecialchars($testimonial['text']) ?>"</p>
                <div class="testimonial-author"><?= htmlspecialchars($testimonial['name']) ?></div>
                <?php if ($testimonial['company']): ?>
                <div class="testimonial-company"><?= htmlspecialchars($testimonial['company']) ?></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section">
    <div class="container">
        <h2>Projeniz mi Var?</h2>
        <p>Hemen ücretsiz teklif alın, size en uygun çözümü sunalım.</p>
        <a href="/teklif.php" class="btn">
            <i class="fas fa-phone"></i> ÜCRETSİZ TEKLİF AL
        </a>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
