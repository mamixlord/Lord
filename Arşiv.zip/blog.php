<?php
$current_page = 'blog';
$page_title = 'Blog | Bilay Demir Doğrama';
include 'includes/header.php';

$posts = fetchAll("SELECT * FROM blog_posts WHERE published = 1 ORDER BY created_at DESC");
?>

<section class="page-header">
    <div class="container">
        <div class="section-label">BLOG</div>
        <h1>Metal İşçilik Rehberi</h1>
        <p class="text-secondary" style="margin-top: 24px; max-width: 500px; font-size: 18px;">
            Demir doğrama ve metal işçilik hakkında faydalı bilgiler.
        </p>
    </div>
</section>

<section class="section" style="background: var(--bg-primary);">
    <div class="container">
        <?php if (count($posts) > 0): ?>
        <div class="blog-grid">
            <?php foreach ($posts as $post): ?>
            <a href="/blog-detay.php?slug=<?= urlencode($post['slug']) ?>" class="blog-card">
                <?php if ($post['image']): ?>
                <div class="blog-card-image">
                    <img src="<?= htmlspecialchars($post['image']) ?>" alt="<?= htmlspecialchars($post['title']) ?>">
                </div>
                <?php endif; ?>
                <div class="blog-card-content">
                    <div class="blog-card-date">
                        <i class="far fa-calendar"></i> <?= formatDate($post['created_at']) ?>
                    </div>
                    <h3><?= htmlspecialchars($post['title']) ?></h3>
                    <p><?= htmlspecialchars($post['excerpt']) ?></p>
                    <span class="blog-card-link">
                        Devamını Oku <i class="fas fa-arrow-right"></i>
                    </span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="empty-state">
            <p>Henüz blog yazısı eklenmemiş.</p>
            <p>Yakında faydalı içerikler paylaşılacak.</p>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
