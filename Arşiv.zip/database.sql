-- Bilay Demir Dograma Database Schema
-- MySQL 8.0+

CREATE DATABASE IF NOT EXISTS bilay_demir_dograma CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bilay_demir_dograma;

-- Users (Admin)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Services
CREATE TABLE services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    icon VARCHAR(50) DEFAULT 'wrench',
    image VARCHAR(255),
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Projects
CREATE TABLE projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    images TEXT, -- JSON array of image URLs
    featured TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Blog Posts
CREATE TABLE blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    content LONGTEXT,
    excerpt TEXT,
    image VARCHAR(255),
    meta_title VARCHAR(255),
    meta_description TEXT,
    published TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Testimonials
CREATE TABLE testimonials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    company VARCHAR(100),
    text TEXT NOT NULL,
    rating INT DEFAULT 5,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Offer Requests
CREATE TABLE offer_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    service VARCHAR(100),
    width VARCHAR(20),
    height VARCHAR(20),
    message TEXT,
    image VARCHAR(255),
    status ENUM('new', 'contacted', 'completed', 'cancelled') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contact Messages
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    message TEXT NOT NULL,
    status ENUM('unread', 'read') DEFAULT 'unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Site Settings
CREATE TABLE site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT
);

-- SEO Settings
CREATE TABLE seo_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    page_slug VARCHAR(100) NOT NULL UNIQUE,
    meta_title VARCHAR(255),
    meta_description TEXT,
    meta_keywords TEXT,
    content LONGTEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert Default Admin
INSERT INTO users (email, password_hash, name, role) VALUES 
('admin@bilaydemir.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', 'admin');
-- Default password: password (change this!)

-- Insert Default Services
INSERT INTO services (title, description, icon, display_order) VALUES
('Demir Kapı', 'Güçlü ve estetik demir kapılar', 'door', 1),
('Bahçe Çitleri', 'Dayanıklı bahçe çit sistemleri', 'fence', 2),
('CNC Kesim', 'Hassas CNC metal kesim hizmetleri', 'scissors', 3),
('Özel Metal Üretim', 'İsteğe göre özel metal üretim', 'cog', 4),
('Tente Sistemleri', 'Metal tente ve sundurma sistemleri', 'sun', 5),
('Kaynak/Tamir', 'Profesyonel kaynak ve tamir hizmetleri', 'wrench', 6);

-- Insert Default Testimonials
INSERT INTO testimonials (name, company, text, rating) VALUES
('Ahmet Yılmaz', 'Yılmaz İnşaat', 'Muhteşem işçilik, zamanında teslimat.', 5),
('Mehmet Demir', 'Demir Emlak', 'Kaliteli malzeme ve profesyonel hizmet.', 5),
('Ayşe Kaya', NULL, 'Bahçe kapımız harika oldu, teşekkürler!', 5);

-- Insert Default Site Settings
INSERT INTO site_settings (setting_key, setting_value) VALUES
('company_name', 'Bilay Demir Doğrama'),
('phone', '+90 212 XXX XX XX'),
('email', 'info@bilaydemir.com'),
('address', 'Kağıthane, İstanbul'),
('whatsapp', '+905XXXXXXXXX'),
('google_maps_embed', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d48173.29!2d28.97!3d41.08'),
('about_text', 'Bilay Demir Doğrama, 20 yıllık tecrübesiyle metal işlerinde uzman bir firmadır.'),
('working_hours', 'Pazartesi - Cumartesi: 08:00 - 18:00');
