<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'bilay_demir_dograma');
define('DB_USER', 'root');
define('DB_PASS', ''); // Şifrenizi buraya yazın

// Site Configuration
define('SITE_URL', 'https://siteniz.com'); // Sitenizin URL'si
define('SITE_NAME', 'Bilay Demir Doğrama');

// Upload Configuration
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB

// Session Configuration
define('SESSION_LIFETIME', 86400); // 24 saat

// Email Configuration (Gmail SMTP)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', ''); // Gmail adresiniz
define('SMTP_PASS', ''); // Gmail uygulama şifresi
define('ADMIN_EMAIL', 'admin@bilaydemir.com');

// JWT Secret (değiştirin!)
define('JWT_SECRET', 'cok-gizli-bir-anahtar-en-az-32-karakter-olmali');

// Error Reporting (production'da kapatın)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('Europe/Istanbul');
