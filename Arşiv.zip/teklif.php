<?php
$current_page = 'offer';
$page_title = 'Teklif Al | Bilay Demir Doğrama';

include 'includes/header.php';

$success = false;
$error = '';

// Get services for dropdown
$services = fetchAll("SELECT * FROM services ORDER BY display_order ASC");

// Form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $service = sanitize($_POST['service'] ?? '');
    $width = sanitize($_POST['width'] ?? '');
    $height = sanitize($_POST['height'] ?? '');
    $message = sanitize($_POST['message'] ?? '');
    
    if (empty($name) || empty($phone) || empty($service)) {
        $error = 'Lütfen zorunlu alanları doldurun.';
    } else {
        try {
            $imagePath = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $imagePath = uploadFile($_FILES['image']);
            }
            
            insert('offer_requests', [
                'name' => $name,
                'phone' => $phone,
                'service' => $service,
                'width' => $width,
                'height' => $height,
                'message' => $message,
                'image' => $imagePath
            ]);
            
            // Send email notification
            $emailBody = "
                <h2>Yeni Teklif Talebi</h2>
                <p><strong>Ad:</strong> $name</p>
                <p><strong>Telefon:</strong> $phone</p>
                <p><strong>Hizmet:</strong> $service</p>
                <p><strong>Genişlik:</strong> " . ($width ?: 'Belirtilmedi') . "</p>
                <p><strong>Yükseklik:</strong> " . ($height ?: 'Belirtilmedi') . "</p>
                <p><strong>Mesaj:</strong> " . ($message ?: 'Yok') . "</p>
            ";
            sendEmail(ADMIN_EMAIL, 'Yeni Teklif Talebi - Bilay Demir Doğrama', $emailBody);
            
            $success = true;
        } catch (Exception $e) {
            $error = 'Bir hata oluştu: ' . $e->getMessage();
        }
    }
}
?>

<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <div class="section-label">ÜCRETSİZ TEKLİF</div>
        <h1>Projeniz İçin Teklif Alın</h1>
        <p class="text-secondary" style="margin-top: 24px; max-width: 500px; font-size: 18px;">
            Formu doldurun, size özel teklif hazırlayalım.
        </p>
    </div>
</section>

<!-- Offer Form -->
<section class="section" style="background: var(--bg-primary);">
    <div class="container" style="max-width: 700px;">
        <?php if ($success): ?>
        <div style="padding: 48px; background: rgba(255, 90, 0, 0.1); border: 1px solid var(--color-primary); text-align: center;">
            <h2 style="margin-bottom: 16px; color: var(--color-primary);">Teklif Talebiniz Alındı!</h2>
            <p class="text-secondary" style="margin-bottom: 24px;">En kısa sürede sizinle iletişime geçeceğiz.</p>
            <a href="/teklif.php" class="btn btn-outline">Yeni Teklif İste</a>
        </div>
        <?php else: ?>
        
        <form method="POST" enctype="multipart/form-data" data-validate style="padding: 48px; background: var(--bg-surface); border: 1px solid var(--border-color);">
            <h2 style="margin-bottom: 32px;">Teklif Formu</h2>
            
            <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
            <?php endif; ?>
            
            <div class="form-grid">
                <div class="form-group">
                    <label>AD SOYAD *</label>
                    <input type="text" name="name" required placeholder="Adınızı girin">
                </div>
                
                <div class="form-group">
                    <label>TELEFON *</label>
                    <input type="tel" name="phone" required placeholder="Telefon numaranız">
                </div>
            </div>
            
            <div class="form-group">
                <label>HİZMET TÜRÜ *</label>
                <select name="service" required style="background: var(--bg-primary);">
                    <option value="">Hizmet Seçin</option>
                    <?php foreach ($services as $s): ?>
                    <option value="<?= htmlspecialchars($s['title']) ?>"><?= htmlspecialchars($s['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-grid">
                <div class="form-group">
                    <label>GENİŞLİK (cm)</label>
                    <input type="text" name="width" placeholder="Örnek: 200">
                </div>
                
                <div class="form-group">
                    <label>YÜKSEKLİK (cm)</label>
                    <input type="text" name="height" placeholder="Örnek: 180">
                </div>
            </div>
            
            <div class="form-group">
                <label>AÇIKLAMA</label>
                <textarea name="message" rows="4" placeholder="Projeniz hakkında detaylar..."></textarea>
            </div>
            
            <div class="form-group">
                <label>GÖRSEL YÜKLE</label>
                <label class="file-upload">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <span>Görsel seçmek için tıklayın</span>
                    <input type="file" name="image" accept="image/*">
                </label>
            </div>
            
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 12px;">
                <i class="fas fa-paper-plane"></i> Teklif İste
            </button>
        </form>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
