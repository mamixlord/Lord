<?php
$current_page = 'about';
$page_title = 'Hakkımızda | Bilay Demir Doğrama';
include 'includes/header.php';
?>

<section class="page-header">
    <div class="container">
        <div class="section-label">HAKKIMIZDA</div>
        <h1>Bilay Demir Doğrama</h1>
        <p class="text-secondary" style="margin-top: 24px; max-width: 500px; font-size: 18px;">
            20 yıllık tecrübe, yüzlerce mutlu müşteri.
        </p>
    </div>
</section>

<section class="section" style="background: var(--bg-primary);">
    <div class="container">
        <div class="contact-grid" style="align-items: center;">
            <div>
                <h2 style="margin-bottom: 24px;">Hikayemiz</h2>
                <p class="text-secondary" style="line-height: 1.8; margin-bottom: 20px;">
                    Bilay Demir Doğrama, 2004 yılında Kağıthane'de küçük bir atölye olarak kuruldu. 
                    Yıllar içinde büyüyerek İstanbul'un en güvenilir demir doğrama firmalarından biri haline geldik.
                </p>
                <p class="text-secondary" style="line-height: 1.8; margin-bottom: 20px;">
                    Misyonumuz, müşterilerimize en kaliteli malzeme ve işçilikle, zamanında ve uygun fiyatlı 
                    çözümler sunmaktır. Her projede müşteri memnuniyetini ön planda tutuyoruz.
                </p>
                <p class="text-secondary" style="line-height: 1.8;">
                    Modern CNC makinelerimiz ve uzman kadromuzla, demir kapı, bahçe çiti, korkuluk ve 
                    her türlü özel metal üretimi gerçekleştiriyoruz.
                </p>
            </div>
            <div style="aspect-ratio: 4/3; overflow: hidden;">
                <img src="https://images.unsplash.com/photo-1720036237334-9263cd28c3d4?w=800" alt="Bilay Demir Doğrama Atölyesi" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
        </div>
    </div>
</section>

<section class="section" style="background: var(--bg-surface);">
    <div class="container">
        <h2 style="text-align: center; margin-bottom: 64px;">Değerlerimiz</h2>
        <div class="values-grid">
            <div class="card value-card">
                <i class="fas fa-check-circle"></i>
                <h3>Kalite</h3>
                <p>En iyi malzeme ve işçilik</p>
            </div>
            <div class="card value-card">
                <i class="fas fa-handshake"></i>
                <h3>Güven</h3>
                <p>Sözü tutar, zamanında teslim</p>
            </div>
            <div class="card value-card">
                <i class="fas fa-award"></i>
                <h3>Tecrübe</h3>
                <p>20 yıllık sektör bilgisi</p>
            </div>
            <div class="card value-card">
                <i class="fas fa-users"></i>
                <h3>Müşteri Odaklı</h3>
                <p>Sizin için en iyisi</p>
            </div>
        </div>
    </div>
</section>

<section class="stats-section">
    <div class="container">
        <div class="stats-grid">
            <div>
                <div class="stat-value">20+</div>
                <div class="stat-label">Yıl Tecrübe</div>
            </div>
            <div>
                <div class="stat-value">500+</div>
                <div class="stat-label">Proje</div>
            </div>
            <div>
                <div class="stat-value">1000+</div>
                <div class="stat-label">Mutlu Müşteri</div>
            </div>
            <div>
                <div class="stat-value">%100</div>
                <div class="stat-label">Memnuniyet</div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
