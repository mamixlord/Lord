<?php require_once __DIR__ . '/functions.php'; ?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= $meta_description ?? 'Bilay Demir Doğrama - Kağıthane, İstanbul\'da profesyonel demir doğrama, metal işçilik ve CNC kesim hizmetleri.' ?>">
    <meta name="keywords" content="<?= $meta_keywords ?? 'demir doğrama, metal işçilik, CNC kesim, demir kapı, bahçe çiti, İstanbul, Kağıthane' ?>">
    <title><?= $page_title ?? 'Bilay Demir Doğrama | Kağıthane İstanbul' ?></title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <!-- Header -->
    <header class="header" id="header">
        <div class="container header-content">
            <a href="/" class="logo">
                <div class="logo-icon">B</div>
                <div class="logo-text">
                    <span class="logo-name">BILAY</span>
                    <span class="logo-sub">DEMİR DOĞRAMA</span>
                </div>
            </a>
            
            <nav class="nav" id="nav">
                <a href="/" class="nav-link <?= $current_page == 'home' ? 'active' : '' ?>">Ana Sayfa</a>
                <a href="/hizmetler.php" class="nav-link <?= $current_page == 'services' ? 'active' : '' ?>">Hizmetler</a>
                <a href="/projeler.php" class="nav-link <?= $current_page == 'projects' ? 'active' : '' ?>">Projeler</a>
                <a href="/hakkimizda.php" class="nav-link <?= $current_page == 'about' ? 'active' : '' ?>">Hakkımızda</a>
                <a href="/blog.php" class="nav-link <?= $current_page == 'blog' ? 'active' : '' ?>">Blog</a>
                <a href="/iletisim.php" class="nav-link <?= $current_page == 'contact' ? 'active' : '' ?>">İletişim</a>
            </nav>
            
            <a href="/teklif.php" class="btn btn-primary header-cta">
                <i class="fas fa-phone"></i> Teklif Al
            </a>
            
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </header>
    
    <!-- Mobile Menu -->
    <div class="mobile-menu" id="mobileMenu">
        <a href="/" class="mobile-nav-link">Ana Sayfa</a>
        <a href="/hizmetler.php" class="mobile-nav-link">Hizmetler</a>
        <a href="/projeler.php" class="mobile-nav-link">Projeler</a>
        <a href="/hakkimizda.php" class="mobile-nav-link">Hakkımızda</a>
        <a href="/blog.php" class="mobile-nav-link">Blog</a>
        <a href="/iletisim.php" class="mobile-nav-link">İletişim</a>
        <a href="/teklif.php" class="btn btn-primary" style="width: 100%; margin-top: 20px;">
            <i class="fas fa-phone"></i> Teklif Al
        </a>
    </div>
