    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col">
                    <div class="logo" style="margin-bottom: 20px;">
                        <div class="logo-icon">B</div>
                        <div class="logo-text">
                            <span class="logo-name">BILAY</span>
                            <span class="logo-sub">DEMİR DOĞRAMA</span>
                        </div>
                    </div>
                    <p class="text-secondary">20 yıllık tecrübemizle Kağıthane ve İstanbul genelinde kaliteli demir doğrama hizmetleri sunuyoruz.</p>
                </div>
                
                <div class="footer-col">
                    <h4 class="footer-title">Hızlı Erişim</h4>
                    <a href="/hizmetler.php" class="footer-link">Hizmetlerimiz</a>
                    <a href="/projeler.php" class="footer-link">Projelerimiz</a>
                    <a href="/teklif.php" class="footer-link">Teklif Al</a>
                    <a href="/blog.php" class="footer-link">Blog</a>
                    <a href="/iletisim.php" class="footer-link">İletişim</a>
                </div>
                
                <div class="footer-col">
                    <h4 class="footer-title">Hizmetlerimiz</h4>
                    <span class="footer-link">Demir Kapı</span>
                    <span class="footer-link">Bahçe Çitleri</span>
                    <span class="footer-link">CNC Kesim</span>
                    <span class="footer-link">Özel Metal Üretim</span>
                    <span class="footer-link">Tente Sistemleri</span>
                    <span class="footer-link">Kaynak/Tamir</span>
                </div>
                
                <div class="footer-col">
                    <h4 class="footer-title">İletişim</h4>
                    <a href="tel:<?= getSetting('phone', '+902125551234') ?>" class="footer-link">
                        <i class="fas fa-phone"></i> <?= getSetting('phone', '+90 212 555 12 34') ?>
                    </a>
                    <a href="mailto:<?= getSetting('email', 'info@bilaydemir.com') ?>" class="footer-link">
                        <i class="fas fa-envelope"></i> <?= getSetting('email', 'info@bilaydemir.com') ?>
                    </a>
                    <span class="footer-link">
                        <i class="fas fa-map-marker-alt"></i> <?= getSetting('address', 'Kağıthane, İstanbul') ?>
                    </span>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> Bilay Demir Doğrama. Tüm hakları saklıdır.</p>
                <div class="footer-seo-links">
                    <a href="/demir-dograma-istanbul.php">Demir Doğrama İstanbul</a>
                    <a href="/kagithane-demir-dograma.php">Kağıthane Demir Doğrama</a>
                    <a href="/cnc-metal-kesim.php">CNC Metal Kesim</a>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- WhatsApp Button -->
    <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', getSetting('whatsapp', '905551234567')) ?>" 
       target="_blank" 
       class="whatsapp-btn" 
       title="WhatsApp ile iletişime geçin">
        <i class="fab fa-whatsapp"></i>
    </a>
    
    <script src="/assets/js/main.js"></script>
</body>
</html>
